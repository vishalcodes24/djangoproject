from django.apps import AppConfig


class HomeTestConfig(AppConfig):
    name = 'home_test'
