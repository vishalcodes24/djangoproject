# Simple-Clinic-Managment-Project-In-Django
This is simple clinic managment system with django admin,  receptionist and doctor dashboard and online booking for patient. 
